# Flutter_personal_money_app

This is a Flutter Application Project used to manage the daily expenses of a person.

Features:
  Dynamic Chart that shows the expenses of previous 7 days.
  Adding Expenses on particular day
  
# App-Images:
![alt text](https://github.com/a-l-l-a-n/Flutter_Personal_Expenses_App/blob/main/Images/Main_Page.jpeg)
![alt text](https://github.com/a-l-l-a-n/Flutter_Personal_Expenses_App/blob/main/Images/Adding_Transaction.jpeg)

## Getting Started
  Run the main.dart file [Make sure to use android emulator or your own device to run]
